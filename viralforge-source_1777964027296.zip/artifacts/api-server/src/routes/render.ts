import { Router, type IRouter, type Request, type Response } from "express";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { requireAuth } from "../middlewares/requireAuth";
import { isMarket } from "../lib/market-prompts";
import {
  AUDIO_DIR,
  CACHE_DIR,
  MEDIA_DIR,
  RENDERS_DIR,
  UPLOADS_DIR,
  publicUrl,
} from "../lib/paths";
import { ffmpeg, getMediaDuration } from "../lib/ffmpeg";
import { db, historyTable } from "@workspace/db";

const router: IRouter = Router();

interface ClipInput {
  url: string;
  kind: "pexels" | "upload" | "image";
  durationSeconds?: number | null;
}

function isLocalMediaUrl(url: string): boolean {
  return url.startsWith("/api/media/");
}

function localMediaPath(url: string): string {
  const rel = url.replace(/^\/api\/media\//, "");
  return path.join(MEDIA_DIR, rel);
}

async function downloadToFile(url: string, destDir: string, ext: string): Promise<string> {
  const filename = `${crypto.randomBytes(10).toString("hex")}${ext}`;
  const dest = path.join(destDir, filename);
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`Failed to download ${url}: ${resp.status}`);
  const buf = Buffer.from(await resp.arrayBuffer());
  fs.writeFileSync(dest, buf);
  return dest;
}

// Subtle color grading + per-clip motion to give videos a "shot by a human
// creator" look instead of the flat stock-footage feel that AI detectors
// pick up on.
const HUMAN_GRADE = "eq=saturation=1.08:contrast=1.04:gamma=0.97";

function processClip(
  inputPath: string,
  perClipSeconds: number,
  isImage: boolean,
  outDir: string,
  index: number,
): Promise<string> {
  const out = path.join(outDir, `seg_${crypto.randomBytes(6).toString("hex")}.mp4`);
  // Alternate Ken Burns direction across scenes so cuts don't feel mechanical.
  const zoomIn = index % 2 === 0;
  const totalFrames = Math.max(1, Math.round(perClipSeconds * 30));

  return new Promise((resolve, reject) => {
    let cmd = ffmpeg();
    if (isImage) {
      // Stills get a true Ken Burns slow zoom + drift.
      const zExpr = zoomIn
        ? `min(zoom+0.0010,1.15)`
        : `if(eq(on,1),1.15,max(zoom-0.0010,1.0))`;
      const filter = `scale=4096:-2,zoompan=z='${zExpr}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=${totalFrames}:s=1920x1080:fps=30,${HUMAN_GRADE},format=yuv420p`;
      cmd = cmd
        .input(inputPath)
        .inputOptions(["-loop 1", `-t ${perClipSeconds.toFixed(2)}`])
        .outputOptions([
          "-vf",
          filter,
          "-r 30",
          "-c:v libx264",
          "-preset veryfast",
          "-pix_fmt yuv420p",
          "-an",
        ]);
    } else {
      // Video clips get a subtle slow zoom via scale+crop with a time
      // expression. Direction alternates per scene.
      // `-stream_loop -1` makes ffmpeg loop the source clip seamlessly so even
      // a 4-second Pexels clip can fill a 12-second slot — eliminates the
      // freeze-frame at the end that caused audio/video drift.
      const xExpr = zoomIn
        ? `(in_w-out_w)/2 + sin(t*0.4)*30`
        : `(in_w-out_w)/2 - sin(t*0.4)*30`;
      const filter = `scale=2112:1188:force_original_aspect_ratio=increase,crop=1920:1080:x='${xExpr}':y='(in_h-out_h)/2',${HUMAN_GRADE},format=yuv420p,fps=30`;
      cmd = cmd
        .input(inputPath)
        .inputOptions(["-stream_loop", "-1", "-t", perClipSeconds.toFixed(2)])
        .outputOptions([
          "-vf",
          filter,
          "-c:v libx264",
          "-preset veryfast",
          "-pix_fmt yuv420p",
          "-an",
          "-t",
          perClipSeconds.toFixed(2),
        ]);
    }
    cmd.save(out)
      .on("end", () => resolve(out))
      .on("error", (err) => reject(err));
  });
}

function concatSegments(segments: string[], outDir: string): Promise<string> {
  const listPath = path.join(outDir, `list_${crypto.randomBytes(4).toString("hex")}.txt`);
  fs.writeFileSync(
    listPath,
    segments.map((s) => `file '${s.replace(/'/g, "'\\''")}'`).join("\n"),
  );
  const out = path.join(outDir, `concat_${crypto.randomBytes(6).toString("hex")}.mp4`);
  return new Promise((resolve, reject) => {
    ffmpeg()
      .input(listPath)
      .inputOptions(["-f concat", "-safe 0"])
      .outputOptions(["-c copy"])
      .save(out)
      .on("end", () => resolve(out))
      .on("error", (err) => reject(err));
  });
}

function muxAudio(
  videoPath: string,
  audioPath: string,
  audioDurationSeconds: number,
  outPath: string,
): Promise<void> {
  // Lock the final video length to the voiceover length exactly. If the
  // concatenated video is shorter than the audio, `-stream_loop -1` keeps
  // looping the visuals so they cover the whole narration. If it's longer,
  // `-t <audio>` trims it. We re-encode the video here (instead of stream
  // copy) because `-stream_loop` requires a re-encode for correct timestamps.
  return new Promise((resolve, reject) => {
    ffmpeg()
      .input(videoPath)
      .inputOptions(["-stream_loop", "-1"])
      .input(audioPath)
      .outputOptions([
        "-map", "0:v:0",
        "-map", "1:a:0",
        "-c:v", "libx264",
        "-preset", "veryfast",
        "-pix_fmt", "yuv420p",
        "-r", "30",
        "-c:a", "aac",
        "-b:a", "192k",
        "-t", audioDurationSeconds.toFixed(3),
        "-movflags", "+faststart",
      ])
      .save(outPath)
      .on("end", () => resolve())
      .on("error", (err) => reject(err));
  });
}

function makeThumbnail(videoPath: string, outPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    ffmpeg(videoPath)
      .screenshots({
        timestamps: ["1"],
        filename: path.basename(outPath),
        folder: path.dirname(outPath),
        size: "640x360",
      })
      .on("end", () => resolve())
      .on("error", (err) => reject(err));
  });
}

router.post("/render", requireAuth, async (req: Request, res: Response) => {
  const userId = req.user!.id;
  const { title, market, script, audioUrl, voiceName, clips } = req.body as {
    title?: string;
    market?: string;
    script?: string;
    audioUrl?: string;
    voiceName?: string | null;
    clips?: ClipInput[];
  };

  if (
    !title ||
    !market ||
    !isMarket(market) ||
    !script ||
    !audioUrl ||
    !Array.isArray(clips) ||
    clips.length === 0
  ) {
    res
      .status(400)
      .json({ error: "title, market, script, audioUrl, and at least one clip are required" });
    return;
  }

  // Resolve audio path
  let audioPath: string;
  try {
    if (isLocalMediaUrl(audioUrl)) {
      audioPath = localMediaPath(audioUrl);
      if (!fs.existsSync(audioPath)) throw new Error("audio missing");
    } else {
      audioPath = await downloadToFile(audioUrl, AUDIO_DIR, ".mp3");
    }
  } catch (err) {
    req.log.error({ err }, "Failed to resolve audio");
    res.status(400).json({ error: "Could not load voice audio" });
    return;
  }

  let audioDuration = 30;
  try {
    audioDuration = await getMediaDuration(audioPath);
  } catch {
    // keep fallback
  }

  const perClip = Math.max(2.5, audioDuration / clips.length);
  const workDir = path.join(CACHE_DIR, `job_${crypto.randomBytes(6).toString("hex")}`);
  fs.mkdirSync(workDir, { recursive: true });

  const segments: string[] = [];
  try {
    let idx = 0;
    for (const clip of clips) {
      let inputPath: string;
      let isImage = clip.kind === "image";

      if (isLocalMediaUrl(clip.url)) {
        inputPath = localMediaPath(clip.url);
        const ext = path.extname(inputPath).toLowerCase();
        if ([".jpg", ".jpeg", ".png", ".webp"].includes(ext)) isImage = true;
      } else {
        const ext = isImage ? ".jpg" : ".mp4";
        inputPath = await downloadToFile(clip.url, workDir, ext);
      }

      const seg = await processClip(inputPath, perClip, isImage, workDir, idx);
      segments.push(seg);
      idx += 1;
    }

    const concatPath = await concatSegments(segments, workDir);

    const finalName = `vf_${Date.now()}_${crypto.randomBytes(4).toString("hex")}.mp4`;
    const finalPath = path.join(RENDERS_DIR, finalName);
    await muxAudio(concatPath, audioPath, audioDuration, finalPath);

    const thumbName = finalName.replace(/\.mp4$/, ".jpg");
    const thumbPath = path.join(RENDERS_DIR, thumbName);
    try {
      await makeThumbnail(finalPath, thumbPath);
    } catch (err) {
      req.log.warn({ err }, "Thumbnail generation failed");
    }

    let finalDuration = audioDuration;
    try {
      finalDuration = await getMediaDuration(finalPath);
    } catch {
      // keep audio duration
    }

    const mp4Url = publicUrl(finalPath);
    const thumbnailUrl = fs.existsSync(thumbPath) ? publicUrl(thumbPath) : mp4Url;

    const [row] = await db
      .insert(historyTable)
      .values({
        userId,
        title,
        market,
        script,
        voiceName: voiceName ?? null,
        mp4Url,
        thumbnailUrl,
        durationSeconds: finalDuration,
      })
      .returning();

    res.json({
      historyId: row!.id,
      mp4Url,
      thumbnailUrl,
      durationSeconds: finalDuration,
    });
  } catch (err) {
    req.log.error({ err }, "Render failed");
    res.status(500).json({ error: "Render failed. Please try again." });
  } finally {
    // best-effort cleanup of intermediates
    try {
      fs.rmSync(workDir, { recursive: true, force: true });
    } catch {
      // ignore
    }
  }
});

export default router;
