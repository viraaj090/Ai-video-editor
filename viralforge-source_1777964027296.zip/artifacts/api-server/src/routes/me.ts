import { Router, type IRouter, type Request, type Response } from "express";
import { requireAuth } from "../middlewares/requireAuth";
import { ensureCredits, grantShareBonus } from "../lib/credits";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getUserFlags } from "../lib/owner";
import { getGameStats } from "../lib/gamification";

const router: IRouter = Router();

async function buildProfile(userId: string) {
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, userId));
  const credits = await ensureCredits(userId);
  const flags = await getUserFlags(userId);
  const stats = await getGameStats(userId);
  return {
    id: userId,
    email: user?.email ?? null,
    firstName: user?.firstName ?? null,
    lastName: user?.lastName ?? null,
    profileImageUrl: user?.profileImageUrl ?? null,
    creditsRemaining: credits.creditsRemaining,
    totalCreditsUsed: credits.totalCreditsUsed,
    lockedUntil: credits.lockedUntil ? credits.lockedUntil.toISOString() : null,
    shareBonusesClaimed: credits.shareBonusesClaimed,
    isOwner: flags.isOwner,
    unlimited: flags.unlimited,
    unlimitedSource: flags.unlimitedSource,
    hasCustomElevenlabsKey: flags.hasCustomElevenlabsKey,
    xp: stats.xp,
    level: stats.level,
    xpToNextLevel: stats.xpToNextLevel,
    streak: stats.streak,
    bestScore: stats.bestScore,
  };
}

router.get("/me", requireAuth, async (req: Request, res: Response) => {
  res.json(await buildProfile(req.user!.id));
});

router.post("/me/share-bonus", requireAuth, async (req: Request, res: Response) => {
  await grantShareBonus(req.user!.id);
  res.json(await buildProfile(req.user!.id));
});

router.get("/me/integrations", (_req: Request, res: Response) => {
  res.json({
    openai:
      Boolean(process.env.AI_INTEGRATIONS_OPENAI_API_KEY) &&
      Boolean(process.env.AI_INTEGRATIONS_OPENAI_BASE_URL),
    pexels: Boolean(process.env.PEXELS_API_KEY),
    elevenlabs: Boolean(process.env.ELEVENLABS_API_KEY),
  });
});

export default router;
