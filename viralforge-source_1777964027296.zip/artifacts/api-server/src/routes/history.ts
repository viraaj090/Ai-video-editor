import { Router, type IRouter, type Request, type Response } from "express";
import { and, desc, eq } from "drizzle-orm";
import { db, historyTable } from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();

function serialize(row: typeof historyTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    market: row.market,
    script: row.script,
    mp4Url: row.mp4Url,
    thumbnailUrl: row.thumbnailUrl,
    durationSeconds: row.durationSeconds,
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/history", requireAuth, async (req: Request, res: Response) => {
  const rows = await db
    .select()
    .from(historyTable)
    .where(eq(historyTable.userId, req.user!.id))
    .orderBy(desc(historyTable.createdAt))
    .limit(100);
  res.json({ items: rows.map(serialize) });
});

router.get("/history/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "invalid id" });
    return;
  }
  const [row] = await db
    .select()
    .from(historyTable)
    .where(and(eq(historyTable.id, id), eq(historyTable.userId, req.user!.id)));
  if (!row) {
    res.status(404).json({ error: "not found" });
    return;
  }
  res.json(serialize(row));
});

router.delete("/history/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "invalid id" });
    return;
  }
  await db
    .delete(historyTable)
    .where(and(eq(historyTable.id, id), eq(historyTable.userId, req.user!.id)));
  res.status(204).end();
});

export default router;
