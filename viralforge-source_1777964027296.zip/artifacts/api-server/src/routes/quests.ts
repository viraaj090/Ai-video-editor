import { Router, type IRouter, type Request, type Response } from "express";
import { requireAuth } from "../middlewares/requireAuth";
import { db, questsTable } from "@workspace/db";
import { and, desc, eq } from "drizzle-orm";
import {
  pickQuestTemplates,
  XP_BY_DIFFICULTY,
  type QuestDifficulty,
} from "../lib/quest-templates";
import { awardXp, getGameStats } from "../lib/gamification";

const router: IRouter = Router();

function isDifficulty(x: unknown): x is QuestDifficulty {
  return x === "easy" || x === "medium" || x === "hard";
}

function serializeQuest(q: typeof questsTable.$inferSelect) {
  return {
    id: q.id,
    title: q.title,
    description: q.description,
    niche: q.niche ?? null,
    difficulty: q.difficulty as QuestDifficulty,
    xpReward: q.xpReward,
    isCompleted: q.isCompleted,
    completedAt: q.completedAt ? q.completedAt.toISOString() : null,
    createdAt: q.createdAt.toISOString(),
  };
}

router.get("/quests", requireAuth, async (req: Request, res: Response) => {
  const userId = req.user!.id;
  const rows = await db
    .select()
    .from(questsTable)
    .where(eq(questsTable.userId, userId))
    .orderBy(desc(questsTable.createdAt))
    .limit(50);
  const stats = await getGameStats(userId);
  res.json({ quests: rows.map(serializeQuest), stats });
});

router.post("/quests", requireAuth, async (req: Request, res: Response) => {
  const userId = req.user!.id;
  const { niche, difficulty, count } = req.body as {
    niche?: string;
    difficulty?: string;
    count?: number;
  };
  const diff: QuestDifficulty = isDifficulty(difficulty) ? difficulty : "easy";
  const n = typeof count === "number" && count >= 1 && count <= 5 ? count : 1;
  const templates = pickQuestTemplates(n, niche?.trim() || "", diff);
  const inserted = await db
    .insert(questsTable)
    .values(
      templates.map((t) => ({
        userId,
        title: t.title,
        description: t.description,
        niche: niche?.trim() || null,
        difficulty: t.difficulty,
        xpReward: t.xpReward,
      })),
    )
    .returning();
  res.json({ quests: inserted.map(serializeQuest) });
});

router.post("/quests/:id/complete", requireAuth, async (req: Request, res: Response) => {
  const userId = req.user!.id;
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const [quest] = await db
    .select()
    .from(questsTable)
    .where(and(eq(questsTable.id, id), eq(questsTable.userId, userId)));
  if (!quest) {
    res.status(404).json({ error: "Quest not found" });
    return;
  }
  if (quest.isCompleted) {
    res.status(409).json({ error: "Quest already completed" });
    return;
  }
  const [updated] = await db
    .update(questsTable)
    .set({ isCompleted: true, completedAt: new Date() })
    .where(eq(questsTable.id, id))
    .returning();
  const reward = quest.xpReward || XP_BY_DIFFICULTY.easy;
  const award = await awardXp(userId, reward, { updateStreak: false });
  const stats = await getGameStats(userId);
  res.json({
    quest: serializeQuest(updated!),
    reward: {
      xpAwarded: award.xpAwarded,
      levelUp: award.levelUp,
      bonusCreditsGranted: award.bonusCreditsGranted,
    },
    stats,
  });
});

router.delete("/quests", requireAuth, async (req: Request, res: Response) => {
  const userId = req.user!.id;
  await db.delete(questsTable).where(eq(questsTable.userId, userId));
  res.json({ ok: true });
});

export default router;
