import { Router, type IRouter, type Request, type Response } from "express";
import crypto from "crypto";
import { eq, sql } from "drizzle-orm";
import {
  accessCodesTable,
  codeRedemptionsTable,
  db,
  userFlagsTable,
  usersTable,
} from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";
import { requireOwner } from "../middlewares/requireOwner";

const router: IRouter = Router();

function genCode(): string {
  // Friendly 10-char code: VF-XXXXXXXX
  const raw = crypto.randomBytes(6).toString("base64url").replace(/[-_]/g, "").slice(0, 8).toUpperCase();
  return `VF-${raw}`;
}

router.get(
  "/admin/codes",
  requireAuth,
  requireOwner,
  async (_req: Request, res: Response) => {
    const rows = await db
      .select()
      .from(accessCodesTable)
      .orderBy(sql`${accessCodesTable.createdAt} DESC`);
    res.json({
      codes: rows.map((r) => ({
        id: r.id,
        code: r.code,
        label: r.label,
        grantUnlimited: r.grantUnlimited,
        bonusCredits: r.bonusCredits,
        maxUses: r.maxUses,
        usedCount: r.usedCount,
        expiresAt: r.expiresAt ? r.expiresAt.toISOString() : null,
        createdAt: r.createdAt.toISOString(),
      })),
    });
  },
);

router.post(
  "/admin/codes",
  requireAuth,
  requireOwner,
  async (req: Request, res: Response) => {
    const body = req.body as {
      label?: string;
      grantUnlimited?: boolean;
      bonusCredits?: number;
      maxUses?: number;
      expiresAt?: string | null;
    };
    const code = genCode();
    const [created] = await db
      .insert(accessCodesTable)
      .values({
        code,
        label: body.label?.trim() || null,
        grantUnlimited: body.grantUnlimited ?? true,
        bonusCredits: Math.max(0, Math.min(500, body.bonusCredits ?? 0)),
        maxUses: Math.max(1, Math.min(10000, body.maxUses ?? 1)),
        expiresAt: body.expiresAt ? new Date(body.expiresAt) : null,
        createdBy: req.user!.id,
      })
      .returning();
    res.json({
      id: created.id,
      code: created.code,
      label: created.label,
      grantUnlimited: created.grantUnlimited,
      bonusCredits: created.bonusCredits,
      maxUses: created.maxUses,
      usedCount: created.usedCount,
      expiresAt: created.expiresAt ? created.expiresAt.toISOString() : null,
      createdAt: created.createdAt.toISOString(),
    });
  },
);

router.delete(
  "/admin/codes/:id",
  requireAuth,
  requireOwner,
  async (req: Request, res: Response) => {
    const id = parseInt(String(req.params.id), 10);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    await db.delete(accessCodesTable).where(eq(accessCodesTable.id, id));
    await db
      .delete(codeRedemptionsTable)
      .where(eq(codeRedemptionsTable.codeId, id));
    res.status(204).send();
  },
);

router.get(
  "/admin/users",
  requireAuth,
  requireOwner,
  async (_req: Request, res: Response) => {
    const rows = await db
      .select({
        id: usersTable.id,
        email: usersTable.email,
        firstName: usersTable.firstName,
        lastName: usersTable.lastName,
        createdAt: usersTable.createdAt,
        isOwner: userFlagsTable.isOwner,
        unlimited: userFlagsTable.unlimited,
        unlimitedSource: userFlagsTable.unlimitedSource,
      })
      .from(usersTable)
      .leftJoin(userFlagsTable, eq(userFlagsTable.userId, usersTable.id))
      .orderBy(sql`${usersTable.createdAt} DESC`)
      .limit(200);
    res.json({
      users: rows.map((r) => ({
        id: r.id,
        email: r.email,
        firstName: r.firstName,
        lastName: r.lastName,
        createdAt: r.createdAt.toISOString(),
        isOwner: r.isOwner ?? false,
        unlimited: r.unlimited ?? false,
        unlimitedSource: r.unlimitedSource ?? null,
      })),
    });
  },
);

export default router;
