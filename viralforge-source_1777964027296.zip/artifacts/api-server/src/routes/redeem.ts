import { Router, type IRouter, type Request, type Response } from "express";
import { and, eq, sql } from "drizzle-orm";
import {
  accessCodesTable,
  codeRedemptionsTable,
  db,
} from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";
import { setUnlimited } from "../lib/owner";
import { grantBonusCredits } from "../lib/credits";

const router: IRouter = Router();

router.post(
  "/codes/redeem",
  requireAuth,
  async (req: Request, res: Response) => {
    const { code } = req.body as { code?: string };
    if (!code || typeof code !== "string") {
      res.status(400).json({ error: "Code is required" });
      return;
    }
    const trimmed = code.trim().toUpperCase();
    const [row] = await db
      .select()
      .from(accessCodesTable)
      .where(eq(accessCodesTable.code, trimmed));
    if (!row) {
      res.status(404).json({ error: "Code not found" });
      return;
    }
    const now = new Date();
    if (row.expiresAt && row.expiresAt < now) {
      res.status(410).json({ error: "Code has expired" });
      return;
    }
    if (row.usedCount >= row.maxUses) {
      res.status(409).json({ error: "Code is fully redeemed" });
      return;
    }

    // Already redeemed by this user? Just re-apply unlimited (idempotent).
    const [existing] = await db
      .select()
      .from(codeRedemptionsTable)
      .where(
        and(
          eq(codeRedemptionsTable.codeId, row.id),
          eq(codeRedemptionsTable.userId, req.user!.id),
        ),
      );
    if (existing) {
      if (row.grantUnlimited) await setUnlimited(req.user!.id, `code:${row.code}`);
      res.json({
        ok: true,
        alreadyRedeemed: true,
        grantUnlimited: row.grantUnlimited,
        bonusCredits: 0,
      });
      return;
    }

    try {
      await db.insert(codeRedemptionsTable).values({
        codeId: row.id,
        userId: req.user!.id,
      });
      await db
        .update(accessCodesTable)
        .set({ usedCount: sql`${accessCodesTable.usedCount} + 1` })
        .where(eq(accessCodesTable.id, row.id));
    } catch (err) {
      req.log.warn({ err }, "Code redemption insert failed (race?)");
      res.status(409).json({ error: "Code already redeemed" });
      return;
    }

    if (row.grantUnlimited) {
      await setUnlimited(req.user!.id, `code:${row.code}`);
    }
    if (row.bonusCredits > 0) {
      await grantBonusCredits(req.user!.id, row.bonusCredits);
    }

    res.json({
      ok: true,
      alreadyRedeemed: false,
      grantUnlimited: row.grantUnlimited,
      bonusCredits: row.bonusCredits,
    });
  },
);

export default router;
