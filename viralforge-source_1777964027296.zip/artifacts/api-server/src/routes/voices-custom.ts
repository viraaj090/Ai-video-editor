import { Router, type IRouter, type Request, type Response } from "express";
import { and, eq, sql } from "drizzle-orm";
import { db, userCustomVoicesTable } from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";
import { isMarket, type Market } from "../lib/market-prompts";
import {
  getCustomElevenlabsKey,
  setCustomElevenlabsKey,
} from "../lib/owner";

const router: IRouter = Router();

router.get(
  "/voices/custom",
  requireAuth,
  async (req: Request, res: Response) => {
    const rows = await db
      .select()
      .from(userCustomVoicesTable)
      .where(eq(userCustomVoicesTable.userId, req.user!.id))
      .orderBy(sql`${userCustomVoicesTable.createdAt} DESC`);
    res.json({
      voices: rows.map((r) => ({
        id: r.id,
        name: r.name,
        voiceId: r.voiceId,
        market: r.market,
        description: r.description,
        createdAt: r.createdAt.toISOString(),
      })),
    });
  },
);

router.post(
  "/voices/custom",
  requireAuth,
  async (req: Request, res: Response) => {
    const { name, voiceId, market, description } = req.body as {
      name?: string;
      voiceId?: string;
      market?: string;
      description?: string;
    };
    const trimmedName = name?.trim();
    const trimmedVoiceId = voiceId?.trim();
    if (!trimmedName || !trimmedVoiceId || !market || !isMarket(market)) {
      res.status(400).json({
        error: "name, voiceId, and a valid market are required",
      });
      return;
    }
    const [created] = await db
      .insert(userCustomVoicesTable)
      .values({
        userId: req.user!.id,
        name: trimmedName,
        voiceId: trimmedVoiceId,
        market: market as Market,
        description: description?.trim() || null,
      })
      .returning();
    res.json({
      id: created.id,
      name: created.name,
      voiceId: created.voiceId,
      market: created.market,
      description: created.description,
      createdAt: created.createdAt.toISOString(),
    });
  },
);

router.delete(
  "/voices/custom/:id",
  requireAuth,
  async (req: Request, res: Response) => {
    const id = parseInt(String(req.params.id), 10);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    await db
      .delete(userCustomVoicesTable)
      .where(
        and(
          eq(userCustomVoicesTable.id, id),
          eq(userCustomVoicesTable.userId, req.user!.id),
        ),
      );
    res.status(204).send();
  },
);

router.get(
  "/voices/elevenlabs-key",
  requireAuth,
  async (req: Request, res: Response) => {
    const key = await getCustomElevenlabsKey(req.user!.id);
    res.json({ hasKey: Boolean(key) });
  },
);

router.put(
  "/voices/elevenlabs-key",
  requireAuth,
  async (req: Request, res: Response) => {
    const { apiKey } = req.body as { apiKey?: string };
    if (apiKey === undefined) {
      res.status(400).json({ error: "apiKey is required (use null to clear)" });
      return;
    }
    const trimmed = apiKey?.trim() || "";
    await setCustomElevenlabsKey(req.user!.id, trimmed.length > 0 ? trimmed : null);
    res.json({ hasKey: trimmed.length > 0 });
  },
);

export default router;
