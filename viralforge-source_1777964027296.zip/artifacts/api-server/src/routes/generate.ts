import { Router, type IRouter, type Request, type Response } from "express";
import { requireAuth } from "../middlewares/requireAuth";
import { consumeCredit, ensureCredits } from "../lib/credits";
import { getOpenAI, SCRIPT_MODEL } from "../lib/openai-client";
import {
  isMarket,
  marketLanguageHint,
  marketSystemPrompt,
  type Market,
} from "../lib/market-prompts";
import {
  isBuildLength,
  isBuildTone,
  isBuildType,
  TONE_LABEL,
  TYPE_LABEL,
  LENGTH_LABEL,
  type BuildLength,
  type BuildOptions,
  type BuildTone,
  type BuildType,
} from "../lib/build-options";
import { scoreBuild } from "../lib/build-score";
import { awardBuildXp } from "../lib/gamification";

const router: IRouter = Router();

interface ScriptScene {
  order: number;
  narration: string;
  keywords: string[];
}

interface ScriptPayload {
  title: string;
  hook: string;
  fullScript: string;
  scenes: ScriptScene[];
  hashtags: string[];
  chapters?: string[];
  bRollIdeas?: string[];
  monetizationTips?: string[];
}

function safeParseJson(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    const match = text.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        return JSON.parse(match[0]);
      } catch {
        return null;
      }
    }
    return null;
  }
}

router.post("/generate/script", requireAuth, async (req: Request, res: Response) => {
  const userId = req.user!.id;
  const body = req.body as {
    prompt?: string;
    market?: string;
    niche?: string | null;
    targetSeconds?: number | null;
    buildType?: string;
    tone?: string;
    length?: string;
    options?: Partial<BuildOptions>;
  };

  const { prompt, market, niche, targetSeconds } = body;

  if (!prompt || typeof prompt !== "string" || !market || !isMarket(market)) {
    res.status(400).json({ error: "prompt and a valid market are required" });
    return;
  }

  const buildType: BuildType = isBuildType(body.buildType) ? body.buildType : "reel";
  const tone: BuildTone = isBuildTone(body.tone) ? body.tone : "high-energy";
  const length: BuildLength = isBuildLength(body.length) ? body.length : "short";
  const options: BuildOptions = {
    chapters: body.options?.chapters !== false && (buildType === "long" || buildType === "audio"),
    monetize: body.options?.monetize === true,
    broll: body.options?.broll !== false,
  };

  // Pre-flight check: must have credits or fail before calling OpenAI.
  const preState = await ensureCredits(userId);
  const now = new Date();
  if (preState.lockedUntil && preState.lockedUntil > now) {
    res.status(402).json({
      error: "Account locked. Try again after the cooldown or claim a bonus.",
      lockedUntil: preState.lockedUntil.toISOString(),
      creditsRemaining: preState.creditsRemaining,
    });
    return;
  }
  if (preState.creditsRemaining <= 0) {
    const consumed = await consumeCredit(userId);
    res.status(402).json({
      error: "No credits remaining.",
      lockedUntil: consumed.state.lockedUntil
        ? consumed.state.lockedUntil.toISOString()
        : null,
      creditsRemaining: consumed.state.creditsRemaining,
    });
    return;
  }

  const targetLen = targetSeconds && targetSeconds >= 15 ? targetSeconds : 45;
  const sceneCount = Math.max(4, Math.round(targetLen / 6));

  const sys = marketSystemPrompt(market as Market);

  const wantsChapters = options.chapters;
  const wantsBroll = options.broll;
  const wantsMonetize = options.monetize;

  const extraSchemaParts: string[] = [];
  if (wantsChapters) {
    extraSchemaParts.push(`  "chapters": ["00:00 — Hook", "00:15 — Setup", ...]`);
  }
  if (wantsBroll) {
    extraSchemaParts.push(`  "bRollIdeas": ["string", "string"]`);
  }
  if (wantsMonetize) {
    extraSchemaParts.push(`  "monetizationTips": ["string", "string"]`);
  }
  const extraSchema = extraSchemaParts.length
    ? `,\n${extraSchemaParts.join(",\n")}`
    : "";

  const formatGuidance =
    buildType === "long"
      ? `This is a LONG-FORM ${LENGTH_LABEL[length]} plan. The "fullScript" should be a tight VOICEOVER for the opening (≈${targetLen}s) the user can synthesize. Use chapters[] for the full 8–25 minute structure with timestamps.`
      : buildType === "audio"
      ? `This is an AUDIO-FIRST plan. The "fullScript" is the narrator copy. Inside scenes, mention SFX/MUSIC cues in brackets like [SFX: rain] or [MUSIC: tense pad].`
      : `This is a SHORT vertical reel. Keep the fullScript punchy and ready for voice synthesis at ~${targetLen}s.`;

  const user = `Build Type: ${TYPE_LABEL[buildType]}
Tone: ${TONE_LABEL[tone]}
Target Length Bucket: ${LENGTH_LABEL[length]}
Topic: ${prompt}
${niche ? `Niche: ${niche}` : ""}
Target voiceover duration: ~${targetLen} seconds.
Output language: ${marketLanguageHint(market as Market)}

${formatGuidance}

Return JSON exactly matching:
{
  "title": "string (under 60 chars)",
  "hook": "string (first line of the video, the scroll-stopper)",
  "fullScript": "string (the whole voiceover script as one block including the hook)",
  "scenes": [
    { "order": 1, "narration": "string (one or two sentences from fullScript)", "keywords": ["string", "string"] }
  ],
  "hashtags": ["string", "string"]${extraSchema}
}
Produce exactly ${sceneCount} scenes. Concatenated scene narrations should reproduce the full script in order. Each scene should have 2-3 visual keywords.`;

  let parsed: ScriptPayload | null = null;
  try {
    const openai = getOpenAI();
    const completion = await openai.chat.completions.create({
      model: SCRIPT_MODEL,
      response_format: { type: "json_object" },
      temperature: 0.9,
      messages: [
        { role: "system", content: sys },
        { role: "user", content: user },
      ],
    });
    const text = completion.choices[0]?.message?.content ?? "";
    const obj = safeParseJson(text) as ScriptPayload | null;
    if (
      !obj ||
      typeof obj.title !== "string" ||
      typeof obj.hook !== "string" ||
      typeof obj.fullScript !== "string" ||
      !Array.isArray(obj.scenes) ||
      !Array.isArray(obj.hashtags)
    ) {
      throw new Error("AI response did not match expected schema");
    }
    parsed = {
      title: obj.title,
      hook: obj.hook,
      fullScript: obj.fullScript,
      scenes: obj.scenes
        .map((s, i) => ({
          order: typeof s.order === "number" ? s.order : i + 1,
          narration: String(s.narration ?? ""),
          keywords: Array.isArray(s.keywords)
            ? s.keywords.map(String).filter(Boolean)
            : [],
        }))
        .filter((s) => s.narration.length > 0),
      hashtags: obj.hashtags.map(String).filter(Boolean),
      chapters: Array.isArray(obj.chapters)
        ? obj.chapters.map(String).filter(Boolean)
        : undefined,
      bRollIdeas: Array.isArray(obj.bRollIdeas)
        ? obj.bRollIdeas.map(String).filter(Boolean)
        : undefined,
      monetizationTips: Array.isArray(obj.monetizationTips)
        ? obj.monetizationTips.map(String).filter(Boolean)
        : undefined,
    };
  } catch (err) {
    req.log.error({ err }, "Script generation failed");
    res.status(500).json({ error: "Failed to generate script. Please try again." });
    return;
  }

  // Only consume credit on successful generation.
  const consumed = await consumeCredit(userId);

  const qualityScore = scoreBuild({
    hook: parsed.hook,
    fullScript: parsed.fullScript,
    scenes: parsed.scenes,
    hashtags: parsed.hashtags,
    targetSeconds: targetLen,
  });

  const xp = await awardBuildXp(userId, { score: qualityScore });

  res.json({
    title: parsed.title,
    hook: parsed.hook,
    fullScript: parsed.fullScript,
    scenes: parsed.scenes,
    hashtags: parsed.hashtags,
    chapters: parsed.chapters ?? null,
    bRollIdeas: parsed.bRollIdeas ?? null,
    monetizationTips: parsed.monetizationTips ?? null,
    qualityScore,
    buildType,
    tone,
    length,
    market,
    creditsRemaining: consumed.state.creditsRemaining,
    lockedUntil: consumed.state.lockedUntil
      ? consumed.state.lockedUntil.toISOString()
      : null,
    xpAwarded: xp.xpAwarded,
    levelUp: xp.levelUp,
    bonusCreditsGranted: xp.bonusCreditsGranted,
    newLevel: xp.level,
    streak: xp.streak,
  });
});

router.post("/generate/rewrite", requireAuth, async (req: Request, res: Response) => {
  const { script, instruction, market } = req.body as {
    script?: string;
    instruction?: string;
    market?: string;
  };
  if (
    !script ||
    typeof script !== "string" ||
    !instruction ||
    typeof instruction !== "string" ||
    !market ||
    !isMarket(market)
  ) {
    res.status(400).json({ error: "script, instruction, and market are required" });
    return;
  }

  const sys = marketSystemPrompt(market as Market);
  const user = `Existing script:
"""
${script}
"""

User feedback / change request:
"""
${instruction}
"""

Rewrite the script following the user's feedback while keeping the market voice. Output ONLY the new script text — no JSON, no commentary, no quotation marks around the whole thing.`;

  try {
    const openai = getOpenAI();
    const completion = await openai.chat.completions.create({
      model: SCRIPT_MODEL,
      temperature: 0.85,
      messages: [
        { role: "system", content: sys },
        { role: "user", content: user },
      ],
    });
    const text = (completion.choices[0]?.message?.content ?? "").trim();
    if (!text) throw new Error("Empty rewrite response");
    res.json({ script: text });
  } catch (err) {
    req.log.error({ err }, "Script rewrite failed");
    res.status(500).json({ error: "Failed to rewrite script. Please try again." });
  }
});

export default router;
