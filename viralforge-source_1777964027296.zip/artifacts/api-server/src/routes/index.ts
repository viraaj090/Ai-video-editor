import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import meRouter from "./me";
import generateRouter from "./generate";
import mediaRouter from "./media";
import renderRouter from "./render";
import historyRouter from "./history";
import adminRouter from "./admin";
import redeemRouter from "./redeem";
import voicesCustomRouter from "./voices-custom";
import questsRouter from "./quests";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(meRouter);
router.use(generateRouter);
router.use(mediaRouter);
router.use(renderRouter);
router.use(historyRouter);
router.use(adminRouter);
router.use(redeemRouter);
router.use(voicesCustomRouter);
router.use(questsRouter);

export default router;
