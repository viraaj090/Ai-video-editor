import { Router, type IRouter, type Request, type Response } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { requireAuth } from "../middlewares/requireAuth";
import { isVoiceAvailable, listVoicesFor } from "../lib/voices";
import { isMarket, type Market } from "../lib/market-prompts";
import { AUDIO_DIR, UPLOADS_DIR, publicUrl } from "../lib/paths";
import { getMp3Duration } from "../lib/ffmpeg";
import { getCustomElevenlabsKey } from "../lib/owner";

const router: IRouter = Router();

interface PexelsApiVideo {
  id: number;
  duration: number;
  width: number;
  height: number;
  image: string;
  video_files: Array<{
    id: number;
    quality: string;
    file_type: string;
    width: number;
    height: number;
    link: string;
  }>;
}

router.post("/pexels/search", requireAuth, async (req: Request, res: Response) => {
  const apiKey = process.env.PEXELS_API_KEY;
  if (!apiKey) {
    res.status(503).json({ error: "Pexels API key is not configured" });
    return;
  }
  const { keywords, perKeyword } = req.body as {
    keywords?: string[];
    perKeyword?: number;
  };
  if (!Array.isArray(keywords) || keywords.length === 0) {
    res.status(400).json({ error: "keywords array is required" });
    return;
  }
  const per = Math.max(1, Math.min(perKeyword ?? 3, 5));
  const out: Array<{
    id: string;
    keyword: string;
    videoUrl: string;
    thumbnailUrl: string;
    durationSeconds: number;
    width: number;
    height: number;
  }> = [];

  for (const rawKeyword of keywords.slice(0, 10)) {
    const keyword = String(rawKeyword).trim();
    if (!keyword) continue;
    try {
      const url = `https://api.pexels.com/videos/search?query=${encodeURIComponent(keyword)}&per_page=${per}&orientation=landscape&size=medium`;
      const resp = await fetch(url, { headers: { Authorization: apiKey } });
      if (!resp.ok) continue;
      const data = (await resp.json()) as { videos?: PexelsApiVideo[] };
      for (const v of data.videos ?? []) {
        // Pick the smallest 720p+ HD MP4 we can find.
        const candidate = v.video_files
          .filter((f) => f.file_type === "video/mp4" && f.height >= 540)
          .sort((a, b) => a.height - b.height)[0];
        if (!candidate) continue;
        out.push({
          id: String(v.id),
          keyword,
          videoUrl: candidate.link,
          thumbnailUrl: v.image,
          durationSeconds: v.duration,
          width: candidate.width,
          height: candidate.height,
        });
      }
    } catch (err) {
      req.log.warn({ err, keyword }, "Pexels search failed for keyword");
    }
  }

  res.json({ clips: out });
});

router.get("/elevenlabs/voices", async (req: Request, res: Response) => {
  const m = req.query.market;
  const market: Market | undefined =
    typeof m === "string" && isMarket(m) ? (m as Market) : undefined;
  const userId = req.isAuthenticated() ? req.user!.id : undefined;
  // Prefer the user's personal ElevenLabs key so we can fetch every voice in
  // their account (including clones); fall back to the platform key.
  const userKey = userId ? await getCustomElevenlabsKey(userId) : null;
  const apiKey = userKey ?? process.env.ELEVENLABS_API_KEY ?? undefined;
  const list = (await listVoicesFor(userId, market, apiKey)).map((v) => ({
    id: v.id,
    name: v.name,
    accent: v.accent,
    market: v.market,
    description: v.description,
    previewUrl: v.previewUrl ?? null,
    isCustom: Boolean(v.isCustom),
  }));
  res.json({ voices: list });
});

router.post("/elevenlabs/synthesize", requireAuth, async (req: Request, res: Response) => {
  // Prefer the user's personal ElevenLabs key (so they can use ANY voice
  // in their account, including voice clones) and fall back to the global one.
  const userKey = await getCustomElevenlabsKey(req.user!.id);
  const apiKey = userKey ?? process.env.ELEVENLABS_API_KEY;
  if (!apiKey) {
    res.status(503).json({ error: "ElevenLabs API key is not configured" });
    return;
  }
  const { text, voiceId } = req.body as { text?: string; voiceId?: string };
  if (!text || typeof text !== "string" || !voiceId) {
    res.status(400).json({ error: "text and voiceId are required" });
    return;
  }
  // If the user supplied their own ElevenLabs key, trust whatever voiceId they
  // pass through (it's their library). Otherwise restrict to known voices.
  if (!userKey && !(await isVoiceAvailable(req.user!.id, voiceId))) {
    res.status(400).json({ error: "voiceId is not available" });
    return;
  }

  try {
    const url = `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}?output_format=mp3_44100_128`;
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "xi-api-key": apiKey,
        "Content-Type": "application/json",
        Accept: "audio/mpeg",
      },
      body: JSON.stringify({
        text,
        // multilingual_v2 handles Hinglish + accented English well and supports
        // the natural pause markers ("...", em-dashes) we sprinkle into scripts.
        model_id: "eleven_multilingual_v2",
        // Lower stability + higher style => more natural human-like variation,
        // less of the dead-flat AI cadence YouTube's classifier flags.
        voice_settings: {
          stability: 0.32,
          similarity_boost: 0.85,
          style: 0.55,
          use_speaker_boost: true,
        },
      }),
    });
    if (!resp.ok) {
      const errBody = await resp.text();
      req.log.error({ status: resp.status, body: errBody }, "ElevenLabs error");
      res.status(502).json({ error: "Voice synthesis failed" });
      return;
    }
    const buf = Buffer.from(await resp.arrayBuffer());
    const filename = `${crypto.randomBytes(12).toString("hex")}.mp3`;
    const filePath = path.join(AUDIO_DIR, filename);
    fs.writeFileSync(filePath, buf);
    let duration = 0;
    try {
      duration = await getMp3Duration(filePath);
    } catch {
      duration = Math.max(3, Math.round(text.length / 15));
    }
    res.json({ audioUrl: publicUrl(filePath), durationSeconds: duration });
  } catch (err) {
    req.log.error({ err }, "ElevenLabs synthesis crash");
    res.status(500).json({ error: "Voice synthesis failed" });
  }
});

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase() || ".bin";
      cb(null, `${crypto.randomBytes(10).toString("hex")}${ext}`);
    },
  }),
  limits: { fileSize: 50 * 1024 * 1024 },
});

router.post(
  "/uploads",
  requireAuth,
  upload.single("file"),
  (req: Request, res: Response) => {
    if (!req.file) {
      res.status(400).json({ error: "file is required" });
      return;
    }
    const ext = path.extname(req.file.filename).toLowerCase();
    const isVideo = [".mp4", ".mov", ".webm", ".m4v"].includes(ext);
    const isImage = [".jpg", ".jpeg", ".png", ".webp"].includes(ext);
    if (!isVideo && !isImage) {
      try {
        fs.unlinkSync(req.file.path);
      } catch {
        // ignore
      }
      res.status(400).json({ error: "Only JPG/PNG/WEBP images and MP4/MOV videos are allowed" });
      return;
    }
    res.json({
      url: publicUrl(req.file.path),
      kind: isVideo ? "video" : "image",
      originalName: req.file.originalname,
      sizeBytes: req.file.size,
    });
  },
);

export default router;
