export type BuildType = "reel" | "long" | "audio";
export type BuildTone =
  | "cinematic"
  | "friendly"
  | "high-energy"
  | "authoritative"
  | "storytelling"
  | "comedic";
export type BuildLength = "short" | "medium" | "long" | "podcast";

export interface BuildOptions {
  chapters: boolean;
  monetize: boolean;
  broll: boolean;
}

export function isBuildType(x: unknown): x is BuildType {
  return x === "reel" || x === "long" || x === "audio";
}
export function isBuildTone(x: unknown): x is BuildTone {
  return (
    x === "cinematic" ||
    x === "friendly" ||
    x === "high-energy" ||
    x === "authoritative" ||
    x === "storytelling" ||
    x === "comedic"
  );
}
export function isBuildLength(x: unknown): x is BuildLength {
  return x === "short" || x === "medium" || x === "long" || x === "podcast";
}

export const TONE_LABEL: Record<BuildTone, string> = {
  cinematic: "cinematic and premium, with measured pacing",
  friendly: "warm, friendly, and conversational",
  "high-energy": "punchy, high-energy, fast-paced",
  authoritative: "authoritative, expert-led, confident",
  storytelling: "storytelling-driven, narrative arc with reveal",
  comedic: "playful and comedic with light jokes",
};

export const TYPE_LABEL: Record<BuildType, string> = {
  reel: "Short-form vertical reel / Shorts",
  long: "Long-form YouTube video plan (8–25 min)",
  audio: "Audio-first plan (voiceover + SFX/music cues)",
};

export const LENGTH_LABEL: Record<BuildLength, string> = {
  short: "Short (30–60s)",
  medium: "Medium (2–6 min)",
  long: "Long (8–25 min)",
  podcast: "Podcast style (20–60 min)",
};
