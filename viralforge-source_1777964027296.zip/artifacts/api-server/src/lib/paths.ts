import path from "path";
import fs from "fs";

export const MEDIA_DIR = path.resolve(process.cwd(), "media");
export const AUDIO_DIR = path.join(MEDIA_DIR, "audio");
export const UPLOADS_DIR = path.join(MEDIA_DIR, "uploads");
export const RENDERS_DIR = path.join(MEDIA_DIR, "renders");
export const CACHE_DIR = path.join(MEDIA_DIR, "cache");

for (const dir of [MEDIA_DIR, AUDIO_DIR, UPLOADS_DIR, RENDERS_DIR, CACHE_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}

export function publicUrl(absoluteFilePath: string): string {
  const rel = path.relative(MEDIA_DIR, absoluteFilePath);
  return `/api/media/${rel.replace(/\\/g, "/")}`;
}
