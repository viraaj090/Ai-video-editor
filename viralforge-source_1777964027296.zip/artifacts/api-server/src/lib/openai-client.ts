import OpenAI from "openai";

let client: OpenAI | null = null;

export function getOpenAI(): OpenAI {
  if (!client) {
    const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
    const baseURL = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
    if (!apiKey || !baseURL) {
      throw new Error("Replit AI Integration for OpenAI is not configured");
    }
    client = new OpenAI({ apiKey, baseURL });
  }
  return client;
}

export const SCRIPT_MODEL = "gpt-4o-mini";
