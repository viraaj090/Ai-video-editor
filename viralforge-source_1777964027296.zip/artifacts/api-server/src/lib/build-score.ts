interface ScoreInput {
  hook: string;
  fullScript: string;
  scenes: { narration: string; keywords: string[] }[];
  hashtags: string[];
  targetSeconds: number;
}

export function scoreBuild(b: ScoreInput): number {
  let score = 0;

  // Hook: 5..150 chars optimal.
  const hookLen = b.hook.trim().length;
  if (hookLen >= 30 && hookLen <= 140) score += 20;
  else if (hookLen >= 5) score += 10;

  // Script length vs target (≈2.6 words/sec).
  const wordCount = b.fullScript.trim().split(/\s+/).filter(Boolean).length;
  const expected = Math.max(20, b.targetSeconds * 2.6);
  const ratio = wordCount / expected;
  if (ratio >= 0.75 && ratio <= 1.35) score += 30;
  else if (ratio >= 0.5 && ratio <= 1.6) score += 20;
  else if (ratio > 0) score += 10;

  // Scenes: 4..10 ideal.
  const n = b.scenes.length;
  if (n >= 4 && n <= 10) score += 20;
  else if (n >= 2) score += 10;

  // Hashtags: 5+ great, 3+ ok.
  if (b.hashtags.length >= 5) score += 15;
  else if (b.hashtags.length >= 3) score += 10;
  else if (b.hashtags.length >= 1) score += 5;

  // Avg keywords/scene.
  const avgKw = n
    ? b.scenes.reduce((s, sc) => s + sc.keywords.length, 0) / n
    : 0;
  if (avgKw >= 2) score += 15;
  else if (avgKw >= 1) score += 8;

  return Math.max(0, Math.min(100, Math.round(score)));
}
