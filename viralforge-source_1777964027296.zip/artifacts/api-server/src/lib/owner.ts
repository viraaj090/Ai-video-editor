import {
  db,
  userFlagsTable,
  type UserFlags,
} from "@workspace/db";
import { eq, sql } from "drizzle-orm";

export interface OwnerFlags {
  userId: string;
  isOwner: boolean;
  unlimited: boolean;
  unlimitedSource: string | null;
  hasCustomElevenlabsKey: boolean;
}

function rowTo(row: UserFlags): OwnerFlags {
  return {
    userId: row.userId,
    isOwner: row.isOwner,
    unlimited: row.unlimited,
    unlimitedSource: row.unlimitedSource,
    hasCustomElevenlabsKey: Boolean(row.customElevenlabsKey),
  };
}

export async function getUserFlags(userId: string): Promise<OwnerFlags> {
  const [existing] = await db
    .select()
    .from(userFlagsTable)
    .where(eq(userFlagsTable.userId, userId));
  if (existing) return rowTo(existing);

  // First user to ever touch this table becomes the auto-owner.
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(userFlagsTable);

  const isFirst = Number(count) === 0;

  const [created] = await db
    .insert(userFlagsTable)
    .values({
      userId,
      isOwner: isFirst,
      unlimited: isFirst,
      unlimitedSource: isFirst ? "owner-bootstrap" : null,
    })
    .onConflictDoNothing()
    .returning();
  if (created) return rowTo(created);

  const [row] = await db
    .select()
    .from(userFlagsTable)
    .where(eq(userFlagsTable.userId, userId));
  return rowTo(row!);
}

export async function setUnlimited(
  userId: string,
  source: string,
): Promise<OwnerFlags> {
  await getUserFlags(userId); // ensure row exists
  const [updated] = await db
    .update(userFlagsTable)
    .set({ unlimited: true, unlimitedSource: source })
    .where(eq(userFlagsTable.userId, userId))
    .returning();
  return rowTo(updated!);
}

export async function setCustomElevenlabsKey(
  userId: string,
  key: string | null,
): Promise<OwnerFlags> {
  await getUserFlags(userId);
  const [updated] = await db
    .update(userFlagsTable)
    .set({ customElevenlabsKey: key })
    .where(eq(userFlagsTable.userId, userId))
    .returning();
  return rowTo(updated!);
}

export async function getCustomElevenlabsKey(
  userId: string,
): Promise<string | null> {
  const [row] = await db
    .select({ key: userFlagsTable.customElevenlabsKey })
    .from(userFlagsTable)
    .where(eq(userFlagsTable.userId, userId));
  return row?.key ?? null;
}

export async function requireOwnerFlags(userId: string): Promise<OwnerFlags> {
  const flags = await getUserFlags(userId);
  if (!flags.isOwner) {
    throw Object.assign(new Error("forbidden"), { status: 403 });
  }
  return flags;
}
