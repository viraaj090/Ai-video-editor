import { db, userCustomVoicesTable } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import type { Market } from "./market-prompts";

export interface VoiceDef {
  id: string;
  name: string;
  accent: string;
  market: Market;
  description: string;
  previewUrl?: string | null;
  isCustom?: boolean;
}

// Curated ElevenLabs voice IDs from the new default voice set that is
// available on every account, including the free tier. The older "premade"
// voices (Rachel, Adam, Bella, Elli, Josh, etc.) are now treated as library
// voices and require a paid plan, so we avoid them.
//
// All of these voices are paired with the eleven_multilingual_v2 model, which
// handles Hindi/Hinglish surprisingly well even for English-trained voices.
export const VOICES: VoiceDef[] = [
  // India / Hinglish — multilingual model handles the Hindi mix.
  {
    id: "TX3LPaxmHKxFdv7VOQHJ",
    name: "Liam",
    accent: "Indian-English friendly (male)",
    market: "india",
    description:
      "Articulate male voice that pronounces Hinglish naturally with the multilingual model.",
  },
  {
    id: "pFZP5JQG7iQjIQuC4Bku",
    name: "Lily",
    accent: "Hinglish-capable (female)",
    market: "india",
    description:
      "Warm female voice — pairs well with Hindi-English code-mixed scripts.",
  },
  {
    id: "iP95p4xoKVk53GoZ742B",
    name: "Chris",
    accent: "Conversational (male)",
    market: "india",
    description:
      "Casual storyteller voice — works well for tutorial-style Hinglish content.",
  },
  {
    id: "SAz9YHcvj6GT2YYXdXww",
    name: "River",
    accent: "Energetic (non-binary)",
    market: "india",
    description:
      "Lively neutral voice — great for product reviews and reactions in English/Hinglish.",
  },
  // USA
  {
    id: "9BWtsMINqrJLrRacOk9x",
    name: "Aria",
    accent: "American (female)",
    market: "usa",
    description:
      "Confident, expressive American female voice — Gen-Z creator energy.",
  },
  {
    id: "cjVigY5qzO86Huf0OWal",
    name: "Eric",
    accent: "American (male)",
    market: "usa",
    description: "Chill, conversational American male voice with natural delivery.",
  },
  {
    id: "bIHbv24MWmeRgasZH58o",
    name: "Will",
    accent: "American casual (male)",
    market: "usa",
    description: "Laid-back American male voice — perfect for storytelling and vlogs.",
  },
  {
    id: "FGY2WhTYpPnrIDTdsKH5",
    name: "Laura",
    accent: "American upbeat (female)",
    market: "usa",
    description: "Bright, upbeat American female voice — energetic explainer style.",
  },
  // UK
  {
    id: "Xb7hH8MSUJpSbSDYk0k2",
    name: "Alice",
    accent: "British (female)",
    market: "uk",
    description: "Polished British female voice with measured warmth.",
  },
  {
    id: "JBFqnCBsd6RMkjVDRZzb",
    name: "George",
    accent: "British (male)",
    market: "uk",
    description: "Mature British male voice — natural, observational delivery.",
  },
  {
    id: "N2lVS1w4EtoT3dr4eOWO",
    name: "Callum",
    accent: "British intense (male)",
    market: "uk",
    description: "Gravelly British male voice — perfect for dramatic, cinematic narration.",
  },
  {
    id: "onwK4e9ZLuTAKqWW03F9",
    name: "Daniel",
    accent: "British authoritative (male)",
    market: "uk",
    description: "Deep British male voice — news anchor / documentary style.",
  },
  // Global
  {
    id: "XB0fDUnXU5powFXDhCwa",
    name: "Charlotte",
    accent: "Neutral international (female)",
    market: "global",
    description: "Smooth, neutral female voice that works for global audiences.",
  },
  {
    id: "nPczCjzI2devNBz1zQrb",
    name: "Brian",
    accent: "Neutral international (male)",
    market: "global",
    description:
      "Authoritative neutral male voice — works well for explainer style content.",
  },
  {
    id: "IKne3meq5aSn9XLyUdCD",
    name: "Charlie",
    accent: "Australian (male)",
    market: "global",
    description: "Warm Australian male voice — conversational and approachable.",
  },
  {
    id: "EXAVITQu4vr4xnSDxMaL",
    name: "Sarah",
    accent: "Soft global (female)",
    market: "global",
    description: "Soft, intimate female voice — calm and trustworthy delivery.",
  },
  {
    id: "TxGEqnHWrfWFTfGW9XjX",
    name: "Josh",
    accent: "Deep global (male)",
    market: "global",
    description: "Deep, confident male voice — great for high-stakes narration.",
  },
];

// In-memory cache for voices fetched from the user's ElevenLabs account so
// the dropdown stays snappy. Cache TTL is 10 minutes per API key.
interface CacheEntry {
  fetchedAt: number;
  voices: VoiceDef[];
}
const VOICE_CACHE = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 10 * 60 * 1000;

interface ElevenlabsVoice {
  voice_id: string;
  name: string;
  category?: string;
  description?: string | null;
  labels?: Record<string, string> | null;
  preview_url?: string | null;
}

function inferMarket(v: ElevenlabsVoice): Market {
  const labels = v.labels ?? {};
  const accent = (labels.accent ?? "").toLowerCase();
  const language = (labels.language ?? "").toLowerCase();
  if (accent.includes("indian") || language.includes("hindi")) return "india";
  if (accent.includes("british") || accent.includes("english")) return "uk";
  if (accent.includes("american")) return "usa";
  return "global";
}

function describe(v: ElevenlabsVoice): string {
  const labels = v.labels ?? {};
  const parts = [
    labels.gender,
    labels.age,
    labels["use case"] ?? labels.use_case,
    labels.descriptive,
  ].filter(Boolean);
  if (v.description) return v.description;
  if (parts.length > 0) return parts.join(" · ");
  return v.category === "cloned"
    ? "Your cloned ElevenLabs voice."
    : "ElevenLabs voice from your account.";
}

function accentLabel(v: ElevenlabsVoice): string {
  const labels = v.labels ?? {};
  const accent = labels.accent ?? labels.language ?? "";
  const gender = labels.gender ? ` (${labels.gender})` : "";
  return accent ? `${accent}${gender}` : v.category ?? "ElevenLabs";
}

export async function fetchElevenlabsVoices(apiKey: string): Promise<VoiceDef[]> {
  const cached = VOICE_CACHE.get(apiKey);
  if (cached && Date.now() - cached.fetchedAt < CACHE_TTL_MS) {
    return cached.voices;
  }
  try {
    const resp = await fetch("https://api.elevenlabs.io/v1/voices", {
      headers: { "xi-api-key": apiKey, Accept: "application/json" },
    });
    if (!resp.ok) return cached?.voices ?? [];
    const data = (await resp.json()) as { voices?: ElevenlabsVoice[] };
    const voices: VoiceDef[] = (data.voices ?? []).map((v) => ({
      id: v.voice_id,
      name: v.name,
      accent: accentLabel(v),
      market: inferMarket(v),
      description: describe(v),
      previewUrl: v.preview_url ?? null,
    }));
    VOICE_CACHE.set(apiKey, { fetchedAt: Date.now(), voices });
    return voices;
  } catch {
    return cached?.voices ?? [];
  }
}

export function findBuiltinVoice(id: string): VoiceDef | undefined {
  return VOICES.find((v) => v.id === id);
}

// Cache of preview URLs for built-in voices, keyed by voice id. Populated
// lazily by fetching `/v1/voices/{id}` from ElevenLabs the first time we see
// the voice. The preview URL itself is a long-lived public mp3 on Google
// Cloud Storage so it's safe to cache for the life of the process.
const PREVIEW_CACHE = new Map<string, string | null>();
let PREVIEW_INFLIGHT: Promise<void> | null = null;

async function fetchPreviewFor(voiceId: string, apiKey: string): Promise<string | null> {
  if (PREVIEW_CACHE.has(voiceId)) return PREVIEW_CACHE.get(voiceId) ?? null;
  try {
    const resp = await fetch(
      `https://api.elevenlabs.io/v1/voices/${encodeURIComponent(voiceId)}`,
      { headers: { "xi-api-key": apiKey, Accept: "application/json" } },
    );
    if (!resp.ok) {
      PREVIEW_CACHE.set(voiceId, null);
      return null;
    }
    const data = (await resp.json()) as { preview_url?: string | null };
    const url = data.preview_url ?? null;
    PREVIEW_CACHE.set(voiceId, url);
    return url;
  } catch {
    PREVIEW_CACHE.set(voiceId, null);
    return null;
  }
}

async function ensureBuiltinPreviews(apiKey: string | undefined): Promise<void> {
  if (!apiKey) return;
  const missing = VOICES.filter((v) => !PREVIEW_CACHE.has(v.id));
  if (missing.length === 0) return;
  if (PREVIEW_INFLIGHT) {
    await PREVIEW_INFLIGHT;
    return;
  }
  PREVIEW_INFLIGHT = (async () => {
    // Fetch in parallel but bounded by concurrency of 4 to be polite.
    const queue = [...missing];
    const workers = Array.from({ length: 4 }, async () => {
      while (queue.length > 0) {
        const v = queue.shift()!;
        await fetchPreviewFor(v.id, apiKey);
      }
    });
    await Promise.all(workers);
  })();
  try {
    await PREVIEW_INFLIGHT;
  } finally {
    PREVIEW_INFLIGHT = null;
  }
}

export async function listVoicesFor(
  userId: string | undefined,
  market: Market | undefined,
  apiKey: string | undefined,
): Promise<VoiceDef[]> {
  // Best-effort: warm the preview cache so built-in cards have play buttons.
  await ensureBuiltinPreviews(apiKey);
  const builtin = (market ? VOICES.filter((v) => v.market === market) : VOICES).map(
    (v) => ({ ...v, previewUrl: PREVIEW_CACHE.get(v.id) ?? null }),
  );

  // Pull every voice from the connected ElevenLabs account so the user sees
  // the full library (including their own clones), not just the curated set.
  let fromAccount: VoiceDef[] = [];
  if (apiKey) {
    const all = await fetchElevenlabsVoices(apiKey);
    fromAccount = market ? all.filter((v) => v.market === market) : all;
  }

  let custom: VoiceDef[] = [];
  if (userId) {
    const customRows = await db
      .select()
      .from(userCustomVoicesTable)
      .where(eq(userCustomVoicesTable.userId, userId));
    custom = customRows
      .filter((r) => !market || r.market === market)
      .map((r) => ({
        id: r.voiceId,
        name: r.name,
        accent: "Custom voice",
        market: r.market as Market,
        description: r.description ?? "Your own ElevenLabs voice clone.",
        isCustom: true,
      }));
  }

  // Custom first, then account voices, then built-in. Dedup by id (custom wins).
  const merged: VoiceDef[] = [];
  const seen = new Set<string>();
  for (const v of [...custom, ...fromAccount, ...builtin]) {
    if (seen.has(v.id)) continue;
    seen.add(v.id);
    merged.push(v);
  }
  return merged;
}

export async function isVoiceAvailable(
  userId: string,
  voiceId: string,
): Promise<boolean> {
  if (findBuiltinVoice(voiceId)) return true;
  const [row] = await db
    .select()
    .from(userCustomVoicesTable)
    .where(
      and(
        eq(userCustomVoicesTable.userId, userId),
        eq(userCustomVoicesTable.voiceId, voiceId),
      ),
    );
  return Boolean(row);
}
