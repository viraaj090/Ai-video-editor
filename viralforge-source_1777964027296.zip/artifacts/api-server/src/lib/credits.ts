import { db, userCreditsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getUserFlags } from "./owner";

const STARTING_CREDITS = 4;
const LOCKOUT_DAYS = 15;
const UNLIMITED_DISPLAY_CREDITS = 9999;

export interface CreditState {
  userId: string;
  creditsRemaining: number;
  totalCreditsUsed: number;
  shareBonusesClaimed: number;
  lockedUntil: Date | null;
  unlimited: boolean;
}

function rowToState(
  row: typeof userCreditsTable.$inferSelect,
  unlimited: boolean,
): CreditState {
  return {
    userId: row.userId,
    creditsRemaining: unlimited ? UNLIMITED_DISPLAY_CREDITS : row.creditsRemaining,
    totalCreditsUsed: row.totalCreditsUsed,
    shareBonusesClaimed: row.shareBonusesClaimed,
    lockedUntil: unlimited ? null : row.lockedUntil,
    unlimited,
  };
}

export async function ensureCredits(userId: string): Promise<CreditState> {
  const flags = await getUserFlags(userId);
  const [existing] = await db
    .select()
    .from(userCreditsTable)
    .where(eq(userCreditsTable.userId, userId));
  if (existing) return rowToState(existing, flags.unlimited);

  const [created] = await db
    .insert(userCreditsTable)
    .values({
      userId,
      creditsRemaining: STARTING_CREDITS,
      totalCreditsUsed: 0,
      shareBonusesClaimed: 0,
    })
    .onConflictDoNothing()
    .returning();
  if (created) return rowToState(created, flags.unlimited);

  const [row] = await db
    .select()
    .from(userCreditsTable)
    .where(eq(userCreditsTable.userId, userId));
  return rowToState(row!, flags.unlimited);
}

export interface ConsumeResult {
  ok: boolean;
  state: CreditState;
  reason?: "locked" | "no-credits";
}

export async function consumeCredit(userId: string): Promise<ConsumeResult> {
  const state = await ensureCredits(userId);
  // Owner / unlimited users never burn credits.
  if (state.unlimited) {
    return { ok: true, state };
  }

  const now = new Date();

  if (state.lockedUntil && state.lockedUntil > now) {
    return { ok: false, state, reason: "locked" };
  }

  if (state.creditsRemaining <= 0) {
    const lockUntil = new Date(now.getTime() + LOCKOUT_DAYS * 24 * 60 * 60 * 1000);
    const [updated] = await db
      .update(userCreditsTable)
      .set({ lockedUntil: lockUntil })
      .where(eq(userCreditsTable.userId, userId))
      .returning();
    return { ok: false, state: rowToState(updated!, false), reason: "no-credits" };
  }

  const newRemaining = state.creditsRemaining - 1;
  const newTotal = state.totalCreditsUsed + 1;
  const lockedUntil =
    newRemaining === 0
      ? new Date(now.getTime() + LOCKOUT_DAYS * 24 * 60 * 60 * 1000)
      : state.lockedUntil;

  const [updated] = await db
    .update(userCreditsTable)
    .set({
      creditsRemaining: newRemaining,
      totalCreditsUsed: newTotal,
      lockedUntil,
    })
    .where(eq(userCreditsTable.userId, userId))
    .returning();

  return { ok: true, state: rowToState(updated!, false) };
}

export async function grantShareBonus(userId: string): Promise<CreditState> {
  const state = await ensureCredits(userId);
  if (state.unlimited) return state;
  const now = new Date();
  const [updated] = await db
    .update(userCreditsTable)
    .set({
      creditsRemaining: state.creditsRemaining + 1,
      shareBonusesClaimed: state.shareBonusesClaimed + 1,
      lockedUntil:
        state.lockedUntil && state.lockedUntil > now ? null : state.lockedUntil,
    })
    .where(eq(userCreditsTable.userId, userId))
    .returning();
  return rowToState(updated!, false);
}

export async function grantBonusCredits(
  userId: string,
  count: number,
): Promise<CreditState> {
  const state = await ensureCredits(userId);
  if (state.unlimited) return state;
  const now = new Date();
  const [updated] = await db
    .update(userCreditsTable)
    .set({
      creditsRemaining: state.creditsRemaining + count,
      lockedUntil:
        state.lockedUntil && state.lockedUntil > now ? null : state.lockedUntil,
    })
    .where(eq(userCreditsTable.userId, userId))
    .returning();
  return rowToState(updated!, false);
}
