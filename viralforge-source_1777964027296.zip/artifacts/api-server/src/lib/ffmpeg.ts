import ffmpegPath from "@ffmpeg-installer/ffmpeg";
import ffprobePath from "@ffprobe-installer/ffprobe";
import ffmpeg from "fluent-ffmpeg";

ffmpeg.setFfmpegPath(ffmpegPath.path);
ffmpeg.setFfprobePath(ffprobePath.path);

export { ffmpeg };

export function getMp3Duration(filePath: string): Promise<number> {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, data) => {
      if (err) return reject(err);
      const dur = data.format?.duration;
      if (typeof dur !== "number") return reject(new Error("No duration"));
      resolve(dur);
    });
  });
}

export function getMediaDuration(filePath: string): Promise<number> {
  return getMp3Duration(filePath);
}
