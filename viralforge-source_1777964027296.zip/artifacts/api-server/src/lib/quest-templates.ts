export type QuestDifficulty = "easy" | "medium" | "hard";

export interface QuestTemplate {
  title: (ctx: { niche: string }) => string;
  description: (ctx: { niche: string; difficulty: QuestDifficulty }) => string;
}

export const XP_BY_DIFFICULTY: Record<QuestDifficulty, number> = {
  easy: 25,
  medium: 50,
  hard: 100,
};

const TONES = [
  "cinematic",
  "friendly",
  "high-energy",
  "authoritative",
  "storytelling",
  "comedic",
];

const PLATFORMS = ["YouTube Shorts", "Instagram Reels", "TikTok", "Facebook Reels"];

const TEMPLATES: QuestTemplate[] = [
  {
    title: ({ niche }) => `Forge a ${niche || "trending"} script`,
    description: ({ niche, difficulty }) =>
      `Generate a fresh ${niche || "viral"} script using the Builder. ${difficulty === "hard" ? "Aim for a quality score above 80." : difficulty === "medium" ? "Pick a non-default tone and length." : "Any topic counts."}`,
  },
  {
    title: () => "Try a new tone of voice",
    description: ({ difficulty }) => {
      const pick = TONES[Math.floor(Math.random() * TONES.length)];
      return `Build at least one script with the ${pick} tone. ${difficulty === "hard" ? "Then save it to your library." : ""}`.trim();
    },
  },
  {
    title: ({ niche }) => `Plan a long ${niche || "evergreen"} video`,
    description: ({ difficulty }) =>
      `Use Build Type "Long YouTube Video" and turn on chapters + B-roll ideas. ${difficulty === "hard" ? "Also enable monetization tips." : ""}`.trim(),
  },
  {
    title: () => "Cross-platform repurposing",
    description: ({ difficulty }) => {
      const a = PLATFORMS[Math.floor(Math.random() * PLATFORMS.length)];
      const b = PLATFORMS[Math.floor(Math.random() * PLATFORMS.length)];
      return `Generate one script tuned for ${a}${a !== b ? ` and another for ${b}` : ""}. ${difficulty === "hard" ? "Render and download both." : ""}`.trim();
    },
  },
  {
    title: ({ niche }) => `Audio-first ${niche || "content"} plan`,
    description: () =>
      `Use Build Type "Audio Plan" to outline a voiceover-first piece with SFX/music cues. Then synthesize the voice in the Studio.`,
  },
  {
    title: () => "Hook lab",
    description: ({ difficulty }) =>
      `Generate ${difficulty === "easy" ? 1 : difficulty === "medium" ? 2 : 4} script(s) and pick the strongest hook line. Save the winner to your library.`,
  },
  {
    title: () => "Streak day",
    description: () =>
      `Generate at least one script today to keep your daily build streak alive.`,
  },
  {
    title: ({ niche }) => `${niche || "Niche"} hashtag pack`,
    description: () =>
      `Generate one script and copy its hashtag list — keep a personal swipe file for future videos.`,
  },
  {
    title: () => "Render & ship",
    description: ({ difficulty }) =>
      `Render at least one full 1080p MP4 in the Studio${difficulty === "hard" ? " and share it on a social platform" : ""}.`,
  },
  {
    title: () => "Voice match",
    description: () =>
      `Browse the ElevenLabs voice list and pick a fresh voice that matches your market — then synthesize at least one preview.`,
  },
];

export function pickQuestTemplates(
  count: number,
  niche: string,
  difficulty: QuestDifficulty,
): { title: string; description: string; xpReward: number; difficulty: QuestDifficulty }[] {
  const indices = new Set<number>();
  while (indices.size < Math.min(count, TEMPLATES.length)) {
    indices.add(Math.floor(Math.random() * TEMPLATES.length));
  }
  const xp = XP_BY_DIFFICULTY[difficulty];
  return [...indices].map((i) => {
    const tpl = TEMPLATES[i]!;
    return {
      title: tpl.title({ niche }),
      description: tpl.description({ niche, difficulty }),
      xpReward: xp,
      difficulty,
    };
  });
}
