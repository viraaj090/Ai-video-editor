import { db, userCreditsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { ensureCredits, grantBonusCredits } from "./credits";

const XP_PER_LEVEL_BASE = 100;
const XP_PER_BUILD = 25;

export function computeLevel(xp: number): number {
  if (xp <= 0) return 1;
  return Math.floor(Math.sqrt(xp / XP_PER_LEVEL_BASE)) + 1;
}

export function xpForNextLevel(xp: number): number {
  const lvl = computeLevel(xp);
  const nextLvlXp = (lvl) * (lvl) * XP_PER_LEVEL_BASE;
  return Math.max(0, nextLvlXp - xp);
}

function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function diffDays(a: string, b: string): number {
  const da = new Date(a + "T00:00:00Z").getTime();
  const db = new Date(b + "T00:00:00Z").getTime();
  return Math.round((db - da) / (24 * 60 * 60 * 1000));
}

export interface XpAwardResult {
  xp: number;
  xpAwarded: number;
  level: number;
  previousLevel: number;
  levelUp: boolean;
  bonusCreditsGranted: number;
  streak: number;
  bestScore: number;
}

export async function awardBuildXp(
  userId: string,
  options?: { score?: number },
): Promise<XpAwardResult> {
  return awardXp(userId, XP_PER_BUILD, { updateStreak: true, score: options?.score });
}

export async function awardXp(
  userId: string,
  amount: number,
  opts: { updateStreak?: boolean; score?: number } = {},
): Promise<XpAwardResult> {
  const before = await ensureCredits(userId);
  const [row] = await db
    .select()
    .from(userCreditsTable)
    .where(eq(userCreditsTable.userId, userId));
  const previousXp = row?.xp ?? 0;
  const previousLevel = computeLevel(previousXp);
  const previousStreak = row?.streakCount ?? 0;
  const previousBest = row?.bestScore ?? 0;

  let nextStreak = previousStreak;
  const today = isoDate(new Date());
  if (opts.updateStreak) {
    if (!row?.lastBuildDate) {
      nextStreak = 1;
    } else {
      const last = typeof row.lastBuildDate === "string"
        ? row.lastBuildDate
        : isoDate(row.lastBuildDate as unknown as Date);
      const days = diffDays(last, today);
      if (days <= 0) {
        nextStreak = Math.max(1, previousStreak);
      } else if (days === 1) {
        nextStreak = previousStreak + 1;
      } else {
        nextStreak = 1;
      }
    }
  }

  const score = typeof opts.score === "number" ? Math.max(0, Math.round(opts.score)) : 0;
  const bestScore = Math.max(previousBest, score);
  const newXp = previousXp + Math.max(0, amount);
  const newLevel = computeLevel(newXp);

  const update: Partial<typeof userCreditsTable.$inferInsert> = {
    xp: newXp,
    bestScore,
  };
  if (opts.updateStreak) {
    update.streakCount = nextStreak;
    update.lastBuildDate = today;
  }
  await db
    .update(userCreditsTable)
    .set(update)
    .where(eq(userCreditsTable.userId, userId));

  // Grant +1 credit per new level reached above last rewarded level (capped at 1 per call).
  let bonusCreditsGranted = 0;
  if (newLevel > previousLevel && !before.unlimited) {
    const [refreshed] = await db
      .select()
      .from(userCreditsTable)
      .where(eq(userCreditsTable.userId, userId));
    const lastReward = refreshed?.highestLevelRewarded ?? 1;
    if (newLevel > lastReward) {
      bonusCreditsGranted = newLevel - lastReward;
      await grantBonusCredits(userId, bonusCreditsGranted);
      await db
        .update(userCreditsTable)
        .set({ highestLevelRewarded: newLevel })
        .where(eq(userCreditsTable.userId, userId));
    }
  }

  return {
    xp: newXp,
    xpAwarded: amount,
    level: newLevel,
    previousLevel,
    levelUp: newLevel > previousLevel,
    bonusCreditsGranted,
    streak: opts.updateStreak ? nextStreak : previousStreak,
    bestScore,
  };
}

export async function getGameStats(userId: string) {
  await ensureCredits(userId);
  const [row] = await db
    .select()
    .from(userCreditsTable)
    .where(eq(userCreditsTable.userId, userId));
  const xp = row?.xp ?? 0;
  return {
    xp,
    level: computeLevel(xp),
    xpToNextLevel: xpForNextLevel(xp),
    streak: row?.streakCount ?? 0,
    bestScore: row?.bestScore ?? 0,
    lastBuildDate: row?.lastBuildDate
      ? typeof row.lastBuildDate === "string"
        ? row.lastBuildDate
        : isoDate(row.lastBuildDate as unknown as Date)
      : null,
  };
}
