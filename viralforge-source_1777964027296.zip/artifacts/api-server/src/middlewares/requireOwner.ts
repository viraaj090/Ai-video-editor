import { type Request, type Response, type NextFunction } from "express";
import { getUserFlags } from "../lib/owner";

export async function requireOwner(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const flags = await getUserFlags(req.user!.id);
  if (!flags.isOwner) {
    res.status(403).json({ error: "Owner only" });
    return;
  }
  next();
}
