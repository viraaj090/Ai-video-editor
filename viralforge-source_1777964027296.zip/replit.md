# ViralForge

## Overview

ViralForge is a global YouTube automation SaaS that turns any topic into a market-tuned short video. Users pick a market (India / USA / UK / Global), type a topic, and get a viral-style script in the right language and slang, an ElevenLabs voiceover, Pexels stock clips, and a 1080p MP4 they can download or upload to YouTube.

## Free-tier rules

- 4 free credits, then a 15-day cooldown.
- Sharing on WhatsApp instantly grants +1 credit (and clears any active lockout).

## Owner & access codes

- The very first user to log in is auto-flagged as the **owner** with unlimited generations (lazy bootstrap inside `getUserFlags`).
- The owner can mint **access codes** (`VF-XXXXXXXX`) at `/admin`. Each code can grant unlimited access and/or bonus credits, with configurable max-uses. Codes are shareable links (just copy & send the code).
- Anyone can redeem a code at `/settings#redeem`. Unlimited users skip the credit deduction and lockout entirely.

## Custom voices & personal API keys

- `/settings` lets any user paste an arbitrary ElevenLabs voice ID (incl. their own clones) and assign it to a market.
- Users can also save a **personal ElevenLabs API key** — when set, all of their voice synthesis hits ElevenLabs with their key, unlocking paid library voices.
- When a personal key is present, voice ID validation is skipped (any voice ID works).
- The voice picker now ships with **17 curated default voices** across India / USA / UK / Global (male, female, non-binary, multiple accents) and **dynamically fetches every voice in the connected ElevenLabs account** (clones included) via `GET https://api.elevenlabs.io/v1/voices`, cached for 10 minutes per API key in `voices.ts`.

## Gamification (Builder XP, Streaks, Quests, Build Score)

ViralForge ships a built-in creator game layer (inspired by the Pro Video Builder PWA) that lives **in-app** alongside the existing Studio:

- **XP & Levels** — every successful build awards 25 XP. Level formula: `floor(sqrt(xp / 100)) + 1`. Leveling up grants +1 bonus credit (tracked via `userCredits.highestLevelRewarded` to prevent double-grants).
- **Daily Streak** — `userCredits.streakCount` bumps when a build happens on the next calendar day, resets on a >1-day gap, and is a no-op for same-day builds.
- **Build Score (0–100)** — computed in `lib/build-score.ts` from hook strength, script length match, scene count (4–10), hashtag count, and avg keywords/scene. Displayed as a colored quality bar + score pill on the script result.
- **Build types / Tone / Length** — Studio's `ScriptForm` now exposes Reel / Long YouTube / Audio Plan presets, six tones, and four length buckets. Long & Audio enable optional **chapters**, **B-roll & shot ideas**, and **monetization tips** sections returned by `/api/generate/script` and rendered by `ScriptDisplay`.
- **Earn Quests (`/quests`)** — page lets users spin daily creator challenges from 10 templates (`lib/quest-templates.ts`) at three difficulties (25/50/100 XP). Quests are entirely local — no AI calls, no credits — and clearing them awards XP that can trigger level-up bonus credits. Backed by `questsTable` and `routes/quests.ts` (`GET/POST/DELETE /api/quests`, `POST /api/quests/:id/complete`).
- **TopBar pills** — `GameStatsPills` show level + XP and streak in the top bar on md+ screens; the user dropdown adds an "Earn quests" entry.

DB additions on `userCredits`: `xp`, `streakCount`, `bestScore`, `lastBuildDate`, `highestLevelRewarded`. New table `quests`: `id`, `userId`, `title`, `description`, `niche`, `difficulty`, `xpReward`, `isCompleted`, `completedAt`, timestamps.

## Manual script mode

- The Studio's `ScriptForm` exposes a **Manual Script Mode** toggle. When enabled, the user types/pastes their own script (plus optional title and comma-separated visual keywords) and clicks "Use this script" — no OpenAI call, no credit consumed.
- `Studio.onUseManualScript` splits the text into ~6-second scenes by sentence, distributes the user's keywords across them, and feeds the synthetic `ScriptGeneration` into the existing Voice → Clips → Render pipeline.

## Audio/video sync

- Per-clip ffmpeg processing now uses `-stream_loop -1` on video inputs so even a 4-second Pexels clip seamlessly loops to fill its scene slot (eliminates the freeze-frame at the end of short clips).
- The final mux re-encodes the concatenated video with `-stream_loop -1` and `-t <audioDuration>` so the rendered MP4 length matches the ElevenLabs voiceover **exactly**, looping the visuals if shorter and trimming if longer.

## Architecture

pnpm workspace monorepo with three artifacts:

- `artifacts/api-server` — Express 5 API: Replit Auth (OIDC), credits, OpenAI (script + rewrite), Pexels (clip search), ElevenLabs (voice list + synth), Multer uploads, ffmpeg render, history CRUD.
- `artifacts/viralforge` — React + Vite frontend: dark red/white theme, dashboard with tabbed Studio (Script → Voice → Clips → Render), History page, sidebar AI chat for free script rewrites, sponsored slot, market selector, credit pill with live cooldown.
- `artifacts/mockup-sandbox` — design sandbox.

Shared libraries:

- `lib/db` — Drizzle schema (sessions, users, userCredits, history, userFlags, accessCodes, codeRedemptions, userCustomVoices, quests).
- `lib/api-spec` — OpenAPI 3.1 spec, source of truth for routes/schemas.
- `lib/api-client-react` — Orval-generated React Query hooks + types.
- `lib/api-zod` — Orval-generated Zod schemas.
- `lib/replit-auth-web` — `useAuth()` for the web client.

## Stack

- Node 24 · TypeScript 5.9
- Express 5 + Drizzle + PostgreSQL
- React 18 + Vite + Wouter + TanStack Query + shadcn/Radix UI + Tailwind
- Orval for API codegen
- ffmpeg via `@ffmpeg-installer/ffmpeg` and `@ffprobe-installer/ffprobe`

## Integrations

- Replit Auth (OIDC) — login/logout via `/api/login`, `/api/logout`, `/api/auth/user`.
- Replit AI Integrations OpenAI — env: `AI_INTEGRATIONS_OPENAI_API_KEY`, `AI_INTEGRATIONS_OPENAI_BASE_URL` (proxied, no user key needed).
- Pexels — secret: `PEXELS_API_KEY`.
- ElevenLabs — secret: `ELEVENLABS_API_KEY`.

## Key API routes

- `GET /api/me` — credits + lockout
- `POST /api/me/share-bonus` — +1 credit on WhatsApp share intent
- `GET /api/me/integrations` — which providers are configured
- `POST /api/generate/script` — OpenAI 4o-mini, market-aware JSON output (consumes 1 credit). Accepts `buildType` (reel/long/audio), `tone`, `length`, and `options` (chapters / monetize / broll). Returns `qualityScore`, `xpAwarded`, `levelUp`, `newLevel`, `streak`, `bonusCreditsGranted`, plus optional `chapters`, `bRollIdeas`, `monetizationTips`.
- `POST /api/generate/rewrite` — free script rewrite for the chat sidebar
- `POST /api/pexels/search` — batch keyword → clip lookup
- `GET  /api/elevenlabs/voices?market=...` — curated voices per market
- `POST /api/elevenlabs/synthesize` — MP3 voiceover
- `POST /api/uploads` — Multer for user JPG/PNG/WEBP/MP4 swaps
- `POST /api/render` — ffmpeg concat + mux + thumbnail, persists to history
- `GET/DELETE /api/history*` — list / get / delete past renders
- Static `/api/media/*` — serves uploads, voiceovers, rendered MP4s, thumbnails
- `POST /api/redeem` — redeem an access code
- `GET/POST/DELETE /api/voices/custom*` — per-user custom ElevenLabs voice IDs
- `GET/PUT /api/me/elevenlabs-key` — set or clear personal ElevenLabs API key
- `GET/POST/DELETE /api/admin/codes*` — owner-only mint/list/delete access codes
- `GET /api/admin/users` — owner-only user roster
- `GET/POST/DELETE /api/quests` — list / spin / wipe quests (gamification)
- `POST /api/quests/:id/complete` — claim XP and any level-up bonus credit

## Key commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/viralforge run dev` — run web frontend locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
